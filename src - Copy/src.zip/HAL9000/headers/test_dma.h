#pragma once

void
TestDmaPerformance(
    void
    );