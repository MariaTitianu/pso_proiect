#pragma once

#include "assert.h"

FUNC_AssertFunction                 Hal9000Assert;