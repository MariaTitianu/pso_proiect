#pragma once

FUNC_DriverEntry                    DiskDriverEntry;