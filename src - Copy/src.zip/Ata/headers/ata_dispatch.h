#pragma once

FUNC_DriverDispatch              AtaDispatchReadWrite;
FUNC_DriverDispatch              AtaDispatchDeviceControl;