#pragma once

#include "int15.h"

void
DumpInt15Entry(
    IN  PINT15_MEMORY_MAP_ENTRY     MemoryMapEntry
    );