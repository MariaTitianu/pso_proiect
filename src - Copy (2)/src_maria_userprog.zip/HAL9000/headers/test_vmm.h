#pragma once

#include "vmm.h"

void
TestVmmAllocAndFreeFunctions(
    void
    );