#pragma once

FUNC_DriverDispatch              VolDispatchReadWrite;
FUNC_DriverDispatch              VolDispatchDeviceControl;