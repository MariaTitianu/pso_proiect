#pragma once

FUNC_DriverEntry        Eth82574LDriverEntry;